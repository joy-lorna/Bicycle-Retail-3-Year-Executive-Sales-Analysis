QUERY 1:

`--Create two datasets for the two categories`  
``CREATE SCHEMA IF NOT EXISTS `project-f57ec015-00f5-4842-84d.production`;``  
``CREATE SCHEMA IF NOT EXISTS `project-f57ec015-00f5-4842-84d.sales`;``

`-- Create the tables for the two datasets`  
`-- 1. Categories Table`  
``CREATE TABLE IF NOT EXISTS `project-f57ec015-00f5-4842-84d.production.categories` (``  
  `category_id INT64 NOT NULL,`  
  `category_name STRING NOT NULL,`  
  `PRIMARY KEY (category_id) NOT ENFORCED`  
`);`

`-- 2. Brands Table`  
``CREATE TABLE IF NOT EXISTS `project-f57ec015-00f5-4842-84d.production.brands` (``  
  `brand_id INT64 NOT NULL,`  
  `brand_name STRING NOT NULL,`  
  `PRIMARY KEY (brand_id) NOT ENFORCED`  
`);`

`-- 3. Products Table`  
``CREATE TABLE IF NOT EXISTS `project-f57ec015-00f5-4842-84d.production.products` (``  
  `product_id INT64 NOT NULL,`  
  `product_name STRING NOT NULL,`  
  `brand_id INT64 NOT NULL,`  
  `category_id INT64 NOT NULL,`  
  `model_year INT64 NOT NULL,`  
  `list_price NUMERIC NOT NULL,`  
  `PRIMARY KEY (product_id) NOT ENFORCED,`  
  ``FOREIGN KEY (category_id) REFERENCES `project-f57ec015-00f5-4842-84d.production.categories`(category_id) NOT ENFORCED,``  
  ``FOREIGN KEY (brand_id) REFERENCES `project-f57ec015-00f5-4842-84d.production.brands`(brand_id) NOT ENFORCED``  
`);`

`-- 4. Customers Table`  
``CREATE TABLE IF NOT EXISTS `project-f57ec015-00f5-4842-84d.sales.customers` (``  
  `customer_id INT64 NOT NULL,`  
  `first_name STRING NOT NULL,`  
  `last_name STRING NOT NULL,`  
  `phone STRING,`  
  `email STRING NOT NULL,`  
  `street STRING,`  
  `city STRING,`  
  `state STRING,`  
  `zip_code STRING,`  
  `PRIMARY KEY (customer_id) NOT ENFORCED`  
`);`

`-- 5. Stores Table`  
``CREATE TABLE IF NOT EXISTS `project-f57ec015-00f5-4842-84d.sales.stores` (``  
  `store_id INT64 NOT NULL,`  
  `store_name STRING NOT NULL,`  
  `phone STRING,`  
  `email STRING,`  
  `street STRING,`  
  `city STRING,`  
  `state STRING,`  
  `zip_code STRING,`  
  `PRIMARY KEY (store_id) NOT ENFORCED`  
`);`

`-- 6. Staffs Table`  
``CREATE TABLE IF NOT EXISTS `project-f57ec015-00f5-4842-84d.sales.staffs` (``  
  `staff_id INT64 NOT NULL,`  
  `first_name STRING NOT NULL,`  
  `last_name STRING NOT NULL,`  
  `email STRING NOT NULL,`  
  `phone STRING,`  
  `active INT64 NOT NULL,`  
  `store_id INT64 NOT NULL,`  
  `manager_id INT64,`  
  `PRIMARY KEY (staff_id) NOT ENFORCED,`  
  ``FOREIGN KEY (store_id) REFERENCES `project-f57ec015-00f5-4842-84d.sales.stores`(store_id) NOT ENFORCED``  
`);`

`-- 7. Orders Table`  
``CREATE TABLE IF NOT EXISTS `project-f57ec015-00f5-4842-84d.sales.orders` (``  
  `order_id INT64 NOT NULL,`  
  `customer_id INT64,`  
  `order_status INT64 NOT NULL, -- 1 = Pending; 2 = Processing; 3 = Rejected; 4 = Completed`  
  `order_date DATE NOT NULL,`  
  `required_date DATE NOT NULL,`  
  `shipped_date DATE,`  
  `store_id INT64 NOT NULL,`  
  `staff_id INT64 NOT NULL,`  
  `PRIMARY KEY (order_id) NOT ENFORCED,`  
  ``FOREIGN KEY (customer_id) REFERENCES `project-f57ec015-00f5-4842-84d.sales.customers`(customer_id) NOT ENFORCED,``  
  ``FOREIGN KEY (store_id) REFERENCES `project-f57ec015-00f5-4842-84d.sales.stores`(store_id) NOT ENFORCED``  
`);`

`-- 8. Order Items Table`  
``CREATE TABLE IF NOT EXISTS `project-f57ec015-00f5-4842-84d.sales.order_items` (``  
  `order_id INT64 NOT NULL,`  
  `item_id INT64 NOT NULL,`  
  `product_id INT64 NOT NULL,`  
  `quantity INT64 NOT NULL,`  
  `list_price NUMERIC NOT NULL,`  
  `discount NUMERIC DEFAULT 0,`  
  `PRIMARY KEY (order_id, item_id) NOT ENFORCED,`  
  ``FOREIGN KEY (order_id) REFERENCES `project-f57ec015-00f5-4842-84d.sales.orders`(order_id) NOT ENFORCED,``  
  ``FOREIGN KEY (product_id) REFERENCES `project-f57ec015-00f5-4842-84d.production.products`(product_id) NOT ENFORCED``  
`);`

`-- 9. Stocks Table`  
``CREATE TABLE IF NOT EXISTS `project-f57ec015-00f5-4842-84d.production.stocks` (``  
  `store_id INT64 NOT NULL,`  
  `product_id INT64 NOT NULL,`  
  `quantity INT64,`  
  `PRIMARY KEY (store_id, product_id) NOT ENFORCED,`  
  ``FOREIGN KEY (store_id) REFERENCES `project-f57ec015-00f5-4842-84d.sales.stores`(store_id) NOT ENFORCED,``  
  ``FOREIGN KEY (product_id) REFERENCES `project-f57ec015-00f5-4842-84d.production.products`(product_id) NOT ENFORCED``  
`);`

QUERY 2:

`--Load data into the created tables`  
`-- 1. Insert Brands`  
``INSERT INTO `project-f57ec015-00f5-4842-84d.production.brands` (brand_id, brand_name)``  
`VALUES`  
  `(1, 'Electra'),`  
  `(2, 'Haro'),`  
  `(3, 'Heller'),`  
  `(4, 'Pure Cycles'),`  
  `(5, 'Ritchey'),`  
  `(6, 'Strider'),`  
  `(7, 'Sun Bicycles'),`  
  `(8, 'Surly'),`  
  `(9, 'Trek');`

`-- 2. Insert into production.categories`  
``INSERT INTO `project-f57ec015-00f5-4842-84d.production.categories` (category_id, category_name)``  
`VALUES`  
  `(1, 'Children Bicycles'),`  
  `(2, 'Comfort Bicycles'),`  
  `(3, 'Cruisers Bicycles'),`  
  `(4, 'Cyclocross Bicycles'),`  
  `(5, 'Electric Bikes'),`  
  `(6, 'Mountain Bikes'),`  
  `(7, 'Road Bikes');`

`-- 3. Insert into production.products (Partial Sample)`  
``INSERT INTO `project-f57ec015-00f5-4842-84d.production.products` (product_id, product_name, brand_id, category_id, model_year, list_price)``  
`VALUES`  
  `(1, 'Trek 820 - 2016', 9, 6, 2016, 379.99),`  
  `(2, 'Ritchey Timberwolf Frameset - 2016', 5, 6, 2016, 749.99),`  
  `(3, 'Surly Wednesday Frameset - 2016', 8, 6, 2016, 999.99),`  
  `(4, 'Trek Fuel EX 8 29 - 2016', 9, 6, 2016, 2899.99),`  
  `(5, 'Heller Shagamaw Frame - 2016', 3, 6, 2016, 1320.99),`  
  `(6, 'Surly Ice Cream Truck Frameset - 2016', 8, 6, 2016, 469.99),`  
  `(7, 'Trek Slash 8 27.5 - 2016', 9, 6, 2016, 3999.99),`  
  `(8, 'Trek Remedy 29 Carbon Frameset - 2016', 9, 6, 2016, 1799.99),`  
  `(9, 'Trek Conduit+ - 2016', 9, 5, 2016, 2999.99),`  
  `(10, 'Surly Straggler - 2016', 8, 4, 2016, 1549.00);`  
`-- (Continue with remaining product values from the file)`

`-- 4. Insert into sales.orders (Sample showing Date conversion)`  
`-- Original format '20180418' converted to '2018-04-18'`  
``INSERT INTO `project-f57ec015-00f5-4842-84d.sales.orders` (order_id, customer_id, order_status, order_date, required_date, shipped_date, store_id, staff_id)``  
`VALUES`  
  `(1555, 1, 1, '2018-04-18', '2018-04-18', NULL, 2, 7),`  
  `(1556, 4, 2, '2018-04-18', '2018-04-18', NULL, 2, 6),`  
  `(1557, 121, 2, '2018-04-19', '2018-04-19', NULL, 1, 3);`  
`-- (Continue with remaining order values)`

`-- 5. Insert into sales.order_items (Sample)`  
``INSERT INTO `project-f57ec015-00f5-4842-84d.sales.order_items` (order_id, item_id, product_id, quantity, list_price, discount)``  
`VALUES`  
  `(232, 3, 26, 2, 599.99, 0.07),`  
  `(232, 4, 8, 2, 1799.99, 0.1),`  
  `(233, 1, 14, 1, 269.99, 0.1),`  
  `(233, 2, 16, 2, 599.99, 0.1);`  
`-- (Continue with remaining order_item values)`

`-- 6. Insert into production.stocks (Sample)`  
``INSERT INTO `project-f57ec015-00f5-4842-84d.production.stocks` (store_id, product_id, quantity)``  
`VALUES`  
  `(1, 72, 9),`  
  `(1, 73, 7),`  
  `(1, 74, 9),`  
  `(1, 75, 23);`  
`-- (Continue with remaining stock values)`

QUERY 3:

`-- Create a new dataset for the summary table since there are two datasets used`  
``CREATE SCHEMA `project-f57ec015-00f5-4842-84d.BikeStores`;``

`-- Create the summary table`  
``CREATE TABLE `project-f57ec015-00f5-4842-84d.BikeStores.bike_stores` AS``  
  `SELECT`  
    `ord.order_id,`  
    `CONCAT (cus.first_name, ' ', cus.last_name) AS customers,`  
    `cus.city,`  
    `cus.state,`  
    `ord.order_date,`  
    `SUM(ite.quantity) AS total_units,`  
    `SUM(ite.quantity * ite.list_price) AS revenue,`  
    `pro.product_name,`  
    `cat.category_name,`  
    `sto.store_name,`  
    `CONCAT (sta.first_name, ' ', sta.last_name) AS sales_rep,`  
  ``FROM `project-f57ec015-00f5-4842-84d.sales.orders` AS ord``  
  ``JOIN `project-f57ec015-00f5-4842-84d.sales.customers` AS cus``  
    `ON ord.customer_id = cus.customer_id`  
  ``JOIN `project-f57ec015-00f5-4842-84d.sales.order_items` AS ite``  
    `ON ord.order_id = ite.order_id`  
  ``JOIN `project-f57ec015-00f5-4842-84d.production.products` AS pro``  
    `ON ite.product_id = pro.product_id`  
  ``JOIN `project-f57ec015-00f5-4842-84d.production.categories` AS cat``  
    `ON pro.category_id = cat.category_id`  
  ``JOIN `project-f57ec015-00f5-4842-84d.sales.stores` AS sto``  
    `ON ord.store_id = sto.store_id`  
  ``JOIN `project-f57ec015-00f5-4842-84d.sales.staffs` AS sta``  
    `ON ord.staff_id = sta.staff_id`  
  `GROUP BY`  
    `ord.order_id,`  
    `CONCAT (cus.first_name, ' ', cus.last_name),`  
    `cus.city,`  
    `cus.state,`  
    `ord.order_date,`  
    `pro.product_name,`  
    `cat.category_name,`  
    `sto.store_name,`  
    `CONCAT (sta.first_name, ' ', sta.last_name);`  
